<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="MHS">

    <!--favicon icon-->
    <link rel="icon" type="image/png" href="assets/img/favicon.png">

    

    <!--google font-->
    <link href="//fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans|Source+Sans+Pro|Varela" rel="stylesheet"> 


    <!--common style-->
    <link href="assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="assets/vendor/lobicard/css/lobicard.css" rel="stylesheet">
    <link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">
    <link href="assets/vendor/themify-icons/css/themify-icons.css" rel="stylesheet">
    <link href="assets/vendor/weather-icons/css/weather-icons.min.css" rel="stylesheet">

    <!--bs4 data table-->
    <link href="assets/vendor/data-tables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <!--date picker style-->
    <link href="assets/vendor/date-picker/css/bootstrap-datepicker.min.css" rel="stylesheet">
    <link href="assets/vendor/timepicker/css/timepicker.css" rel="stylesheet">

    <!--dropzone-->
    <link href="assets/vendor/dropzone/dropzone.min.css" rel="stylesheet">
    
    <!--toastr-->
    <link href="assets/vendor/toastr-master/toastr.css" rel="stylesheet">
    
    <!--custom css-->
    <link href="assets/css/main.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="assets/vendor/html5shiv.js"></script>
    <script src="assets/vendor/respond.min.js"></script>
    <![endif]-->


    <!--select2-->
    <link href="assets/vendor/select2/css/select2.css" rel="stylesheet">
    <!--jqery steps-->
    <link href="assets/vendor/jquery-steps/jquery.steps.css" rel="stylesheet">
    <!-- Modal -->
    <link rel="stylesheet" href="assets/vendor/jquery-modal/jquery.modal.css" />
    <link rel="stylesheet" href="assets/vendor/month-picker/MonthPicker.min.css" />
    