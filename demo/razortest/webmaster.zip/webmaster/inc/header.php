 <header class="app-header navbar">
        <!--brand start-->
        <div class="navbar-brand">
            <a class="" href="dashboard.php">
               <img src="assets/img/logo.png" class="img-responsive">
            </a>
        </div>
        <!--brand end-->

        <!--left side nav toggle start-->
        <ul class="nav navbar-nav mr-auto">
            <li class="nav-item d-lg-none">
                <button class="navbar-toggler mobile-leftside-toggler" type="button"><i class="ti-align-right"></i></button>
            </li>
            <li class="nav-item d-md-down-none">
                <a class="nav-link navbar-toggler left-sidebar-toggler" href="#"><i class=" ti-align-right"></i></a>
            </li>
            
        </ul>
        <!--left side nav toggle end-->

        <!--right side nav start-->
    </header>