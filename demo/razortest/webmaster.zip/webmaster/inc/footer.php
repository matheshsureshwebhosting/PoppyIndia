    <div id="modal" class="modal" style="width: auto; min-width: 400px; padding: 50px;" data-backdrop="static" data-keyboard="false">
    </div>