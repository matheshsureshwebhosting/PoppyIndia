<?php
require_once 'connection.php';
require_once 'functions.php';
require_once 'admin.php'; 

//Content
require_once 'features/features.php'; 
require_once 'features/featuresinit.php';

?>