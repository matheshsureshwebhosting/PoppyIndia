<!--toastr-->
    <link href="vendor/toastr-master/toastr.css" rel="stylesheet">

<script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=5ef35c1d08ecd500128efd9b&product=inline-share-buttons&cms=sop' async='async'></script>