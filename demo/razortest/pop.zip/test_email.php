<html>
    <body>
        <div style="font-family:\'Verdana\',\'Open Sans\',sans-serif;font-size:14px;background-color:#ffffff;color:#333333"><div class="adM">
	</div><div style="width:800px;text-align:left"><div class="adM">
		</div><div style="background-color:#ffffff;border:#e5e5e5 solid 1px"><div class="adM">
			</div><div style="background-color:#84226D; font-size:25px;color: #FFF;font-family: verdana,sans-serif, 'Open Sans';padding: 10px;"> POPPY MATTRESS - ORDER CONFIRMATION
 </a>
			</div>
			<div style="padding:10px;line-height:24px">
				<div>Hi Krishnan!,</div>
				<br>
<div>
Thank you for your purchase. Your Order is confirmed <br>
You are ____ nights away from sleeping on your favorite choice of mattress from Poppy’s  <br>
We are looking forward to be your sleep companion. <br>
Are you missing something? <a href="https://www.poppyindia.com">Click Here</a>



					<br><br><br>
				</div>
				<div>Ragards,<br>
				Poppy Team,<br>
				support@poppyindia.com</div>
				
				<div style="font-size:12px;padding:10px 0 0 0;line-height:16px">
					<div class="yj6qo ajU"><div id=":187" class="ajR" role="button" tabindex="0" aria-label="Hide expanded content" data-tooltip="Hide expanded content"><img class="ajT" src="//ssl.gstatic.com/ui/v1/icons/mail/images/cleardot.gif"></div></div><span class="HOEnZb adL"><font color="#888888"><br><span class="il"> </span> <br> 
				</font></span></div><span class="HOEnZb adL"><font color="#888888">
			</font></span></div><span class="HOEnZb adL"><font color="#888888">
		</font></span></div><span class="HOEnZb adL"><font color="#888888">
		<div style="padding:5px 0px 0px 10px">
			
		</div>
	</font></span></div><div class="adL">
</div></div>
    </body>
</html>