<?php include("lib/common.php"); session_start();
$order=$objMain->getRow("select * from orders where id=".$_SESSION['order_id']);
$address=$order['address'].",".$order['city'].",".$order['state']."-".$order['pincode'];
$user=$objMain->getRow("select * from customers where id=".$_SESSION['userid']);
if($user['emailid']!='') $emailid=$user['emailid'];
else $emailid='techaveo@gmail.com';
?>
<html>
  <head>
<TITLE>Pay Now</title>
  </head>
  <body>
    <h2 style="font-family:'Palatino Linotype', 'Book Antiqua', Palatino, serif; font-size:80px; text-align:center; margin-top:100px;"><img src="http://poppyindia.com/demo/images/icons/poppy-logo.gif" style="max-width:300px;"></h2>
    <div style="margin-top:20px; text-align:center; font-size:26px;"><br>Loading Please Wait</div>
    <br/>
    
    <form method="POST" action="https://api.razorpay.com/v1/checkout/embedded" name="redirect" id="redirect">
  <input type="hidden" name="key_id" value="rzp_live_urMd6CrygUGJK6">
  <input type="hidden" name="order_id" value="<?php echo $_SESSION['order_token']; ?>">
  <input type="hidden" name="name" value="Poppy Mattress">
  <input type="hidden" name="description" value="Sleep Well to Live and Fully Awake!">
  <input type="hidden" name="image" value="http://poppyindia.com/demo/images/logo.png">
  <input type="hidden" name="prefill[name]" value="">
  <input type="hidden" name="prefill[contact]" value="<?php echo $order['mobileno']; ?>">
  <input type="hidden" name="prefill[email]" value="techaveo@gmail.com">
  <input type="hidden" name="notes[shipping address]" value="<?php echo $address; ?>">
  <input type="hidden" name="callback_url" value="https://www.poppyindia.com/demo/payment-success.php">
<input type="hidden" name="cancel_url" value="https://www.poppyindia.com/demo/payment-failure.php">
</form>
    
  </body>
  <script language='javascript'>document.redirect.submit();</script>
</html>