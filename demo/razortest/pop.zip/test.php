<?php include("lib/common.php");



/*
$otpmsg='Your OTP : 4659 ';
$apiKey = urlencode('335958AEcvLtgyxyS5f112ac4P1');
    
    // Message details
    $numbers = urlencode('9566322752');
    $sender = urlencode('POPPYS');
    $message = rawurlencode($otpmsg);
 
    // Prepare data for POST request
    $data = 'authkey=' . $apiKey . '&route=4&country=91&mobiles=' . $numbers . "&sender=" . $sender . "&message=" . $message;

    // Send the GET request with cURL
    $ch = curl_init('http://api.msg91.com/api/sendhttp.php?' . $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    
    print_r($response);
    
    echo "<br><br>";
    
    echo 'http://api.msg91.com/api/sendhttp.php?' . $data; */
    
 ?>

