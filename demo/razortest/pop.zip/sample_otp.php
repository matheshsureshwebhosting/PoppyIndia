<?php include("lib/common.php"); 

$order=$objMain->getRow("select * from orders where id=100215");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Sample from Godaddy</title>
</head>
<body>

	<?php $body='<table width="100%" cellpadding="0" cellspacing="0" bgcolor="#F5F5F5" style="text-align:center">

<tbody><tr>

<td>      

<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#F5F5F5">

    <tbody><tr>

	<td bgcolor="#F5F5F5" style="background-color:#f5f5f5;padding-top:0;padding-right:0;padding-left:0;padding-bottom:0">

		<div style="max-width:640px;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;padding-left:0;padding-right:0">

			

			<table cellpadding="0" cellspacing="0" border="0" align="center" width="100%" style="font-family:sans-serif;color:#111111">

				<tbody><tr>

					<td style="padding-top:10px;padding-right:0;padding-bottom:20px;padding-left:0">

						<table cellpadding="0" cellspacing="0" border="0" align="center" width="100%">

                          <tbody><tr>

                             <td width="174" align="left" class="m_26581947998977289stretch" style="padding-top:10px;padding-bottom:0;padding-right:0;padding-left:0">

                                <table width="100%" cellpadding="0" cellspacing="0" border="0" align="left">

                                   <tbody><tr>

                                      <td class="m_26581947998977289mobile-padding-fix m_26581947998977289mobiletextalign" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:16px">

                                         <a href="https://www.poppyindia.com"><img class="m_26581947998977289stretch-img CToWUd" src="http://poppyindia.com/demo/images/logo.png" width="158" height="54" border="0" alt="Poppy Mattress" style="display:block;color:#111111;font-family:Arial,sans-serif;font-size:12px;border:0;width:100%;max-width:158px;min-width:20px;height:auto"></a>

                                      </td>

                                   </tr>

                                </tbody></table>

                             </td>

                             <td align="right" class="m_26581947998977289stretch" style="padding-top:10px;padding-bottom:0;padding-right:0;padding-left:0">

                                <table width="100%" cellpadding="0" cellspacing="0" border="0">

                                   <tbody><tr>

                                      <td align="right" class="m_26581947998977289mobile-padding-fix-right m_26581947998977289mobiletextalign" style="padding-top:0;padding-bottom:0px;padding-left:0;padding-right:20px;text-align:right">

                                         <p class="m_26581947998977289mobiletextalign" style="margin-top:0px;margin-bottom:0px;font-family:\'gdsherpa\',Helvetica,Arial,sans-serif;font-size:13px;line-height:21px">

                                            Need help? <a href="https://www.poppyindia.com/contactus.php">Contact us.</a><br>Customer Number: +91 96982 80808

                                         </p>

                                      </td>

                                   </tr>

                                </tbody></table>

                             </td>

                          </tr>

                       </tbody></table>

                    </td>

                          </tr>

                       </tbody></table>

			

		</div>

	</td>

	</tr>

</tbody></table>





<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#F5F5F5">

    <tbody><tr>

	<td bgcolor="#F5F5F5" style="background-color:#f5f5f5;padding-top:0;padding-right:0;padding-left:0;padding-bottom:0">

		<div style="max-width:600px;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;padding-left:20px;padding-right:20px">

			

			<table bgcolor="#84226D" width="100%" align="center" border="0" cellspacing="0" cellpadding="0" style="font-family:serif;color:#ffffff">

				<tbody><tr>

				<td bgcolor="#84226D" align="left" class="m_26581947998977289h1-primary-mobile" style="padding-top:60px;padding-bottom:0;padding-right:40px;padding-left:40px;text-align:left;background-color:#84226D;font-size:36px;line-height:46px;font-weight:bold;font-family:\'Times New Roman\',Times,serif,\'gd-sage-bold\'">

                

					<span>Welcome to Poppy’s </span>

                        

				</td>

				</tr>

			</tbody></table>

            

		</div>

	</td>

	</tr>

</tbody></table>





<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#F5F5F5">

    <tbody><tr>

	<td bgcolor="#F5F5F5" style="background-color:#f5f5f5;padding-top:0;padding-right:0;padding-left:0;padding-bottom:0">

		<div style="max-width:600px;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;padding-left:20px;padding-right:20px">

			

<table bgcolor="#84226D" width="100%" align="center" border="0" cellspacing="0" cellpadding="0" style="font-family:sans-serif;color:#ffffff">

	<tbody><tr>

	<td dir="ltr" bgcolor="#84226D" align="left" style="padding-top:40px;padding-bottom:0;padding-right:40px;padding-left:40px;text-align:left;background-color:#84226D">



		<p style="Margin-top:0px;Margin-bottom:0px;font-family:\'gdsherpa\',Helvetica,Arial,sans-serif;font-size:16px;line-height:26px">

		We are glad that you are here <br><br>

		<b style="font-size:18px;">One quick way to get started </b><br>
		
		Poppy’s is a mattress company that brings products that promises customer with the dream sleep that they have been longing for. Here are in ways to dive right in <br><br>

		<b style="font-size:17px">OTP : 1123 </b> <br>

		Start your exploration of products from Poppy’s. You are just one step away from dream sleep. Type the given OTP number and experience the personalized shopping with us. <br><br>

		</p>

                        

	</td>

	</tr>

</tbody></table>

            

		</div>

	</td>

	</tr>

</tbody></table>



<table width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#F5F5F5">

     <tbody><tr>

        <td style="padding-top:0px;padding-bottom:0px" bgcolor="#F5F5F5">

           <div style="max-width:600px;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;padding-left:20px;padding-right:20px">

              

                       <table style="border-spacing:0;font-family:sans-serif;color:#111111;margin:0 auto;width:100%;max-width:600px" bgcolor="#84226D" align="center">

                          <tbody><tr>

                             <td style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0">

                                <table style="border-spacing:0;font-family:sans-serif;color:#111111" width="100%">

                                   <tbody><tr>

                                      <td style="padding-top:60px;padding-bottom:0px;padding-left:40px;padding-right:40px;background-color:#84226D;width:100%;text-align:left">

                                         <p style="margin-top:0px;line-height:0px;margin-bottom:0px;font-size:4px">&nbsp;</p>

                                      </td>

                                   </tr>

                                </tbody></table>

                             </td>

                          </tr>

                       </tbody></table>

                       

           </div>

        </td>

     </tr>

  </tbody></table>








  <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#F5F5F5">

     <tbody><tr>

        <td bgcolor="#F5F5F5" style="padding-top:0px;padding-bottom:0px">

           <div style="max-width:600px;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;padding-left:20px;padding-right:20px">

              

                       <table bgcolor="#F5F5F5" align="center" style="border-spacing:0;font-family:sans-serif;color:#111111;margin:0 auto;width:100%;max-width:600px">

                          <tbody><tr>

                             <td style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0">

                                <table width="100%" style="border-spacing:0;font-family:sans-serif;color:#111111">

                                   <tbody><tr>

                                      <td style="padding-top:30px;padding-bottom:0px;padding-left:40px;padding-right:40px;background-color:#f5f5f5;width:100%;text-align:left">

                                         <p style="margin-top:0px;line-height:0px;margin-bottom:0px;font-size:4px">&nbsp;</p>

                                      </td>

                                   </tr>

                                </tbody></table>

                             </td>

                          </tr>

                       </tbody></table>

                       

           </div>

        </td>

     </tr>

  </tbody></table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#F5F5F5">

    <tbody><tr>

  <td bgcolor="#F5F5F5" style="background-color:#f5f5f5;padding-top:0;padding-right:0;padding-left:0;padding-bottom:0">

    <div style="max-width:600px;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;padding-left:20px;padding-right:20px">

      

      <table width="100%" align="left" border="0" cellspacing="0" cellpadding="0" style="font-family:sans-serif;color:#767676">

        <tbody><tr>

        <td align="left" style="padding-top:10px;padding-bottom:0;padding-right:0;padding-left:0;text-align:left">

                

          <p style="text-align:left;Margin-top:0px;Margin-bottom:0px;font-family:\'gdsherpa\',Helvetica,Arial,sans-serif;font-size:12px;line-height:22px">

            Please do not reply to this email. Emails sent to this address will not be answered.

          </p>

                        

        </td>

        </tr>

      </tbody></table>

            

    </div>

  </td>

  </tr>

</tbody></table>


<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#F5F5F5">

    <tbody><tr>

	<td bgcolor="#F5F5F5" style="background-color:#f5f5f5;padding-top:0;padding-right:0;padding-left:0;padding-bottom:0">

		<div style="max-width:600px;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;padding-left:20px;padding-right:20px">

			

			<table width="100%" align="left" border="0" cellspacing="0" cellpadding="0" style="font-family:sans-serif;color:#767676">

				<tbody><tr>

				<td align="left" style="padding-top:10px;padding-bottom:0;padding-right:0;padding-left:0;text-align:left">

                

					<p style="text-align:left;Margin-top:0px;Margin-bottom:0px;font-family:\'gdsherpa\',Helvetica,Arial,sans-serif;font-size:12px;line-height:22px">

						Copyright © 1999-2020 Poppy Mattress Pvt Ltd. All rights reserved.

					</p>

                        

				</td>

				</tr>

			</tbody></table>

            

		</div>

	</td>

	</tr>

</tbody></table>





  <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#F5F5F5">

     <tbody><tr>

        <td bgcolor="#F5F5F5" style="padding-top:0px;padding-bottom:0px">

           <div style="max-width:600px;margin-top:0;margin-bottom:0;margin-right:auto;margin-left:auto;padding-left:20px;padding-right:20px">

              

                       <table bgcolor="#F5F5F5" align="center" style="border-spacing:0;font-family:sans-serif;color:#111111;margin:0 auto;width:100%;max-width:600px">

                          <tbody><tr>

                             <td style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0">

                                <table width="100%" style="border-spacing:0;font-family:sans-serif;color:#111111">

                                   <tbody><tr>

                                      <td style="padding-top:40px;padding-bottom:0px;padding-left:40px;padding-right:40px;background-color:#f5f5f5;width:100%;text-align:left">

                                         <p style="margin-top:0px;line-height:0px;margin-bottom:0px;font-size:4px">&nbsp;</p>

                                      </td>

                                   </tr>

                                </tbody></table>

                             </td>

                          </tr>

                       </tbody></table>

                       

           </div>

        </td>

     </tr>

  </tbody></table>





</td>

</tr>

</tbody></table>';

echo $body;
?>

</body>
</html>